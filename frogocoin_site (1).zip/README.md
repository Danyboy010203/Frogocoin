# FrogoCoin Landing Page

This repository contains a simple bilingual (FR/EN) static landing page for **FrogoCoin (FROGO)**.

## Files
- `index.html` — main bilingual landing page (click the **EN/FR** button to toggle).
- `README.md` — this file.
- `LICENSE` — MIT license.

## Deploy to GitHub Pages
1. Create a new repository on GitHub (e.g. `frogocoin`).
2. Upload `index.html` to the repository root.
3. Go to **Settings → Pages** (or **Pages** in the sidebar), choose **branch: main** and **folder: / (root)**.
4. Save — your site will be available at `https://<your-username>.github.io/<repo-name>/`.

## Quick deploy with Netlify (drag & drop)
1. Go to https://app.netlify.com/drop
2. Drop the contents of this ZIP (or the `index.html` file).
3. Netlify will deploy and give you a public URL.

## Notes
- Replace placeholder links (whitepaper, audit, smart contract) with actual URLs.
- If you want a custom domain, configure DNS to point to GitHub Pages or Netlify.
- This page is intentionally minimal and static for ease of deployment.
